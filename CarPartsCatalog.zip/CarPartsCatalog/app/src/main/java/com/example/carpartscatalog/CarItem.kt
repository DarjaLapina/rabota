package com.example.carpartscatalog

data class CarItem(val name: String, val imageResId: Int)