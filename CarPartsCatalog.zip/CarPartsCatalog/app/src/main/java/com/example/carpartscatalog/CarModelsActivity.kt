package com.example.carpartscatalog

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CarModelsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_car_models)

        // Получаем переданное имя автомобиля
        val carName = intent.getStringExtra("CAR_NAME")

        // Отображаем имя автомобиля в TextView
        val textView: TextView = findViewById(R.id.car_name_text_view)
        textView.text = carName
    }
}